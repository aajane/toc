package com.toc.controller;

import java.awt.PageAttributes.MediaType;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.bson.Document;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.mongodb.BasicDBObject;
import com.mongodb.Cursor;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.util.JSON;

@Controller
@RequestMapping("/second")
@ComponentScan
@SuppressWarnings("all")
public class ReverseRender {
	static JSONObject mytoc = new JSONObject();
	JSONObject object;
	String str, str2, str2b, str3;

//this method to receive data
	@RequestMapping(value = "/postajax", method = RequestMethod.POST)
	public void postedajax(@RequestBody String str, HttpServletResponse response) throws ParseException {
		response.setHeader("Content-Type", "application/json; charset=ISO-8859-1");
		this.str = str;
		System.out.println(str);
	}

	public JSONObject mains() throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONArray jsonarray = (JSONArray) parser.parse(str);
		object = (JSONObject) jsonarray.get(0);
		// level subject
		HashMap subjectData = (HashMap) object.get("data");
		object.put("_version", subjectData.get("_version"));
		object.put("_lang", subjectData.get("_lang"));
		object.put("_icon", subjectData.get("_icon"));
		object.put("_display_name", object.get("text"));
		object.put("_learning_engine", subjectData.get("_learning_engine"));
		object.put("_grade", subjectData.get("_grade"));
		object.put("_curriculum", subjectData.get("_curriculum"));
		object.put("assessment_options", subjectData.get("assessment_options"));

		object.remove("id");
		object.put("_display_name", object.remove("text")); // comment this line if you want to restrict user from
															// changing subject name
		object.remove("a_attr");
		object.remove("li_attr");
		object.remove("icon");
		object.remove("type");
		object.remove("state");
		object.remove("data");
		object.put("ge", object.remove("children"));

		// level chapter
		ArrayList chapterList = (ArrayList) object.get("ge");
		for (int i = 0; i < chapterList.size(); i++) {
			HashMap chapterMap = (HashMap) chapterList.get(i);
			HashMap chapterData = (HashMap) chapterMap.get("data");
			chapterMap.put("_unlocked", chapterData.get("_unlocked"));
			chapterMap.put("_learning_status", chapterData.get("_learning_status"));
			chapterMap.put("_icon", chapterData.get("_icon"));
			chapterMap.put("_display_name", chapterMap.get("text"));
			chapterMap.put("_qat_category_id", chapterData.get("_qat_category_id"));
			chapterMap.put("_id", chapterData.get("_id"));
			chapterMap.put("_isClickable", chapterData.get("_isClickable"));
			if (chapterMap.get("_isClickable") == null) {
				chapterMap.remove("_isClickable");
			}

			chapterMap.remove("a_attr");
			chapterMap.remove("data");
			chapterMap.remove("li_attr");
			chapterMap.remove("icon");
			chapterMap.remove("type");
			chapterMap.remove("state");
			chapterMap.remove("text");
			chapterMap.remove("id");
			chapterMap.put("ge", chapterMap.remove("children"));
			chapterMap.put("ce", chapterMap.get("ge"));

			// level Section
			ArrayList sectionList = (ArrayList) chapterMap.get("ge");
			for (int j = 0; j < sectionList.size(); j++) {
				HashMap sectionMap = (HashMap) sectionList.get(j);
				HashMap sectionData = (HashMap) sectionMap.get("data");
				sectionMap.put("_unlocked", sectionData.get("_unlocked"));
				sectionMap.put("_learning_status", sectionData.get("_learning_status"));
				sectionMap.put("_display_name", sectionMap.get("text"));
				sectionMap.put("_qat_category_id", sectionData.get("_qat_category_id"));
				sectionMap.put("_id", sectionData.get("_id"));

				sectionMap.put("_type", sectionData.get("_type"));
				sectionMap.put("_url", sectionData.get("_url"));
				sectionMap.put("flow_rule", sectionData.get("flow_rule"));

				sectionMap.remove("a_attr");
				sectionMap.remove("data");
				sectionMap.remove("li_attr");
				sectionMap.remove("icon");
				sectionMap.remove("type");
				sectionMap.remove("state");
				sectionMap.remove("text");
				sectionMap.remove("id");
				sectionMap.values().removeAll(Collections.singleton(null));
				// collecting ce array

				sectionMap.put("ge", sectionMap.remove("children"));
				JSONArray secarray = new JSONArray();
				sectionMap.put("ce", secarray);

				// level topic
				ArrayList topicList = (ArrayList) sectionMap.get("ge");
				for (int k = 0; k < topicList.size(); k++) {
					HashMap topicMap = (HashMap) topicList.get(k);
					HashMap topicData = (HashMap) topicMap.get("data");

					topicMap.put("_unlocked", topicData.get("_unlocked"));
					topicMap.put("_learning_status", topicData.get("_learning_status"));
					topicMap.put("_display_name", topicMap.get("text"));
					topicMap.put("_qat_category_id", topicData.get("_qat_category_id"));
					topicMap.put("_id", topicData.get("_id"));
					topicMap.put("_icon", topicData.get("_icon"));
					topicMap.put("_demo_content", topicData.get("_demo_content"));
					topicMap.put("_notes", topicData.get("_notes"));
					topicMap.put("_description", topicData.get("_description"));
					
					// topic dlos funcionality
					ArrayList dloList = (ArrayList) topicMap.get("children");
					for (int l = 0; l < dloList.size(); l++) {
						HashMap dloMap = (HashMap) dloList.get(l);
						HashMap dloData = (HashMap) dloMap.get("data");

						// subactivity if present
						ArrayList subactivityList = (ArrayList) dloMap.get("children");
						for (int m = 0; m < subactivityList.size(); m++) {
							HashMap subactivityMap = (HashMap) subactivityList.get(m);
							HashMap subactivityData = (HashMap) subactivityMap.get("data");
							subactivityMap.put("_display_name", subactivityMap.get("text"));
							subactivityMap.put("_type", subactivityData.get("_type"));
							subactivityMap.put("flow_rule", subactivityData.get("flow_rule"));
							subactivityMap.put("_url", subactivityData.get("_url"));
							subactivityMap.put("_id", subactivityData.get("_id"));
							subactivityMap.remove("a_attr");
							subactivityMap.remove("data");
							subactivityMap.remove("li_attr");
							subactivityMap.remove("icon");
							subactivityMap.remove("type");
							subactivityMap.remove("state");
							subactivityMap.remove("text");
							subactivityMap.remove("id");
							subactivityMap.remove("children"); // It's removed here to avoid null values
						}

						if (subactivityList.size() > 0) {
							// this is essential to remove all null values from 'sce' arrays
							dloMap.put("sce", dloMap.remove("children"));
						}

						dloMap.remove("a_attr");
						dloMap.remove("data");
						dloMap.remove("li_attr");
						dloMap.remove("icon");
						dloMap.remove("type");
						dloMap.remove("state");
						dloMap.remove("id");
						dloMap.remove("children"); // as Children contains 'sce', its removed here

						dloMap.put("_display_name", dloMap.remove("text"));
						dloMap.put("_banner", dloData.get("_banner"));
						dloMap.put("_id", dloData.get("_id"));
						dloMap.put("_type", dloData.get("_type"));
						dloMap.put("_url", dloData.get("_url"));
						dloMap.put("flow_rule", dloData.get("flow_rule"));
						dloMap.put("_icon", dloData.get("_icon"));
						dloMap.put("_CEW", dloData.get("_CEW"));
						dloMap.put("_RE", dloData.get("_RE"));
						dloMap.put("_min_eff_time", dloData.get("_min_eff_time"));
						dloMap.put("_max_eff_time", dloData.get("_max_eff_time"));
						dloMap.put("_qat_category_id", dloData.get("_qat_category_id"));
						dloMap.put("no_instructions", dloData.get("no_instructions"));
						dloMap.values().removeAll(Collections.singleton(null)); // remove all null hashmaps
					}
//topicMap written here as it contains childern and data
					topicMap.put("ce", topicMap.remove("children"));
					topicMap.remove("a_attr");
					topicMap.remove("data");
					topicMap.remove("li_attr");
					topicMap.remove("icon");
					topicMap.remove("type");
					topicMap.remove("state");
					topicMap.remove("text");
					topicMap.remove("id");
				}
			}
		}
		return object;
	}

//this method collects geArray 
	public JSONObject getge() throws IOException, ParseException {
		JSONObject mytoc2 = mains();
		HashMap subjectMap = (HashMap) object.get("toc");
		ArrayList chapterList = (ArrayList) object.get("ge");
		for (int i = 0; i < chapterList.size(); i++) {
			HashMap chapterMap = (HashMap) chapterList.get(i);
			ArrayList sectionList = (ArrayList) chapterMap.get("ge");
			for (int j = 0; j < sectionList.size(); j++) {
				HashMap sectionMap = (HashMap) sectionList.get(j);
				if (sectionMap.containsKey("flow_rule")) {
					sectionMap.clear();
				}
			}
		}
		return mytoc2;
	}

//this method collects ceArray 
	public JSONObject getce() throws IOException, ParseException {
		JSONObject mytoc3 = mains();
		HashMap subjectMap = (HashMap) object.get("toc");
		ArrayList chapterList = (ArrayList) object.get("ge");
		for (int i = 0; i < chapterList.size(); i++) {
			HashMap chapterMap = (HashMap) chapterList.get(i);
			ArrayList sectionList = (ArrayList) chapterMap.get("ge");
			for (int j = 0; j < sectionList.size(); j++) {
				HashMap sectionMap = (HashMap) sectionList.get(j);
				if (!sectionMap.containsKey("flow_rule")) {
					sectionMap.clear();
				}
			}
		}
		return mytoc3;
	}

//this method distinguishes ge and ce
	public JSONObject mixer() throws IOException, ParseException {
		JSONObject toca = getge(); // contains real ge
		JSONObject tocb = getce(); // contains real ce

		ArrayList array1a = (ArrayList) toca.get("ge");
		ArrayList array1b = (ArrayList) tocb.get("ge");

		for (int i = 0; i < array1a.size(); i++) {
			HashMap hash1 = (HashMap) array1a.get(i);
			HashMap hash2 = (HashMap) array1b.get(i);

			ArrayList array2a = (ArrayList) hash1.get("ge");
			ArrayList array2b = (ArrayList) hash2.get("ce");

			ArrayList list = new ArrayList();
			ArrayList list2 = new ArrayList();

//removing null hashmaps from arraylist
			for (int d = 0; d < array2a.size(); d++) {
				HashMap element = (HashMap) array2a.get(d);
				HashMap element2 = (HashMap) array2b.get(d);
				if (!element.isEmpty()) {
					list.add(element);
				}
				if (!element2.isEmpty()) {
					list2.add(element2);
				}
				hash1.put("ge", list);
				hash1.put("ce", list2);
			}

			ArrayList chapterList = (ArrayList) hash1.get("ce");
			for (int e = 0; e < chapterList.size(); e++) {
				HashMap map = (HashMap) chapterList.get(e);
				map.remove("ce");
				map.remove("ge");
			}
		}
		mytoc.put("toc", toca);
		return mytoc;
	}

//this method provides Creation functionality
	public JSONObject creation() throws IOException, ParseException {
		JSONObject myjson = mixer();
		JSONObject j1 = (JSONObject) myjson.get("toc");
		JSONArray arr1 = (JSONArray) j1.get("ge");

		for (int x = 0; x < arr1.size(); x++) {
			JSONObject chapter = (JSONObject) arr1.get(x);
			if (chapter.get("_id") == null) {
				String uuids = UUID.randomUUID().toString().replace("-", "");
				chapter.put("_id", uuids);
			}

			ArrayList arr2b = (ArrayList) chapter.get("ce");
			for (int y2 = 0; y2 < arr2b.size(); y2++) {
				JSONObject test = (JSONObject) arr2b.get(y2);
				if (test.get("_id") == null) {
					String uuids = UUID.randomUUID().toString().replace("-", "");
					test.put("_id", uuids);
				}
			}

			ArrayList arr2 = (ArrayList) chapter.get("ge");
			for (int y = 0; y < arr2.size(); y++) {
				JSONObject section = (JSONObject) arr2.get(y);
				if (section.get("_id") == null) {
					String uuids = UUID.randomUUID().toString().replace("-", "");
					section.put("_id", uuids);
				}

				ArrayList arr3 = (ArrayList) section.get("ge");
				for (int z = 0; z < arr3.size(); z++) {
					JSONObject topic = (JSONObject) arr3.get(z);
					if (topic.get("_id") == null) {
						String uuids = UUID.randomUUID().toString().replace("-", "");
						topic.put("_id", uuids);
					}

					ArrayList arr4 = (ArrayList) topic.get("ce");
					for (int a = 0; a < arr4.size(); a++) {
						JSONObject dlos = (JSONObject) arr4.get(a);

						if (dlos.get("_display_name").equals("Objectives")) {
							if (dlos.get("_id") == null) {
								String uuids = UUID.randomUUID().toString().replace("-", "");
								dlos.put("_id", uuids);
								dlos.put("_type", "objectives");
							}
						}
						if (dlos.get("_display_name").equals("Overview")) {
							if (dlos.get("_id") == null) {
								String uuids = UUID.randomUUID().toString().replace("-", "");
								dlos.put("_id", uuids);
								dlos.put("_type", "concept_overview");
							}
						}
						if (dlos.get("_display_name").equals("LERN Quiz")) {
							if (dlos.get("_id") == null) {
								String uuids = UUID.randomUUID().toString().replace("-", "");
								dlos.put("_id", uuids);
								dlos.put("_type", "lern_quiz");
							}
						}
						if (dlos.get("_display_name").equals("Activity")) {
							if (dlos.get("_id") == null) {
								String uuids = UUID.randomUUID().toString().replace("-", "");
								dlos.put("_id", uuids);
								dlos.put("_type", "activity");
							}
						}
						if (dlos.get("_display_name").equals("Challenge Test")) {
							if (dlos.get("_id") == null) {
								String uuids = UUID.randomUUID().toString().replace("-", "");
								dlos.put("_id", uuids);
								dlos.put("_type", "challenge_test");
							}
						}
						if (dlos.get("_display_name").equals(topic.get("_display_name"))) {
							if (dlos.get("_id") == null) {
								String uuids = UUID.randomUUID().toString().replace("-", "");
								dlos.put("_id", uuids);
								dlos.put("_type", "video");
							}
						}
						if (dlos.get("_display_name").equals("Activity 1")
								| dlos.get("_display_name").equals("Activity 2")
								| dlos.get("_display_name").equals("Activity 3")
								| dlos.get("_display_name").equals("Activity 4")
								| dlos.get("_display_name").equals("Activity 5")
								| dlos.get("_display_name").equals("Activity 6")) {
							dlos.put("_type", "html_activity");
							if (dlos.get("_id") == null) {
								String uuids = UUID.randomUUID().toString().replace("-", "");
								dlos.put("_id", uuids);
								dlos.put("_type", "html_activity");
							}
						}
						if (dlos.get("sce") != null) {
							// since sce is not null, it should be activities
							ArrayList arr5 = (ArrayList) dlos.get("sce");
							dlos.put("_type", "html_activity_list");
							for (int b = 0; b < arr5.size(); b++) {
								JSONObject sce = (JSONObject) arr5.get(b);
								if (sce.get("_id") == null) {
									String uuids = UUID.randomUUID().toString().replace("-", "");
									sce.put("_id", uuids);
									sce.put("_type", "html_activity");
								}
							}
						}
					}
				}
			}
		}
		return myjson;
	}

//this method to receive DLO data as per user's will
	@RequestMapping(value = "/dloajax", method = RequestMethod.POST)
	public ArrayList dloajaxcall(@RequestBody String str2) throws ParseException, IOException {
		this.str2 = str2;
		String[] parts = str2.split(",kk");
		String json = parts[0];
		JSONObject userjson = (JSONObject) new JSONParser().parse(json);
		String userbutton = parts[1].split(",")[1];
		ArrayList myList = new ArrayList<>(Arrays.asList(userjson, userbutton));
		return myList;
	}

//this method used to append same dlo to all topics	as per user's will
	public JSONObject dlouserposition() throws IOException, ParseException {
		JSONObject toc = creation();
		if (str2 != null) {
			ArrayList mydlo = dloajaxcall(str2);
			String userjson = mydlo.get(0).toString();

			String usrButton = (String) mydlo.get(1);
			JSONObject usrJson = (JSONObject) new JSONParser().parse(userjson);
			// here begins toc looping
			JSONObject jso = (JSONObject) toc.get("toc");
			JSONArray arr1 = (JSONArray) jso.get("ge");
			for (int x = 0; x < arr1.size(); x++) {
				JSONObject chapter = (JSONObject) arr1.get(x);
				ArrayList arr2 = (ArrayList) chapter.get("ge");
				for (int y = 0; y < arr2.size(); y++) {
					JSONObject section = (JSONObject) arr2.get(y);
					ArrayList arr3 = (ArrayList) section.get("ge");
					for (int z = 0; z < arr3.size(); z++) {
						JSONObject topic = (JSONObject) arr3.get(z);
						ArrayList arr4 = (ArrayList) topic.get("ce");
						for (int u = 0; u < arr4.size(); u++) {
							JSONObject dlo = (JSONObject) arr4.get(u);

							if (dlo.containsValue(usrButton)) {
								JSONObject tmpDLO = (JSONObject) usrJson.clone();
								String uuids = UUID.randomUUID().toString().replace("-", "").substring(8);
								tmpDLO.put("_id", uuids);
								int i = arr4.indexOf(dlo);
								arr4.add(i + 1, tmpDLO);
							}
						}
					}
				}
			}
		}

		return toc;
	}

	//
	@RequestMapping(value = "/dloajaxone", method = RequestMethod.POST)
	public String dloajaxcallone(@RequestBody String str2b) throws ParseException, IOException {
		this.str2b = str2b;
		return str2b;
	}

	// this method used to append same dlo to all topics in First position
	public JSONObject dloposition1() throws IOException, ParseException {
		JSONObject toc = creation();
		if (str2b != null) {
			String dlostring = dloajaxcallone(str2b);

			JSONObject usrJson = (JSONObject) new JSONParser().parse(dlostring);
			// here begins toc looping
			JSONObject jso = (JSONObject) toc.get("toc");
			JSONArray arr1 = (JSONArray) jso.get("ge");
			for (int x = 0; x < arr1.size(); x++) {
				JSONObject chapter = (JSONObject) arr1.get(x);
				ArrayList arr2 = (ArrayList) chapter.get("ge");
				for (int y = 0; y < arr2.size(); y++) {
					JSONObject section = (JSONObject) arr2.get(y);
					ArrayList arr3 = (ArrayList) section.get("ge");
					for (int z = 0; z < arr3.size(); z++) {
						JSONObject topic = (JSONObject) arr3.get(z);
						ArrayList arr4 = (ArrayList) topic.get("ce");

						JSONObject tmpDLO = (JSONObject) usrJson.clone();
						String uuids = UUID.randomUUID().toString().replace("-", "").substring(8);
						tmpDLO.put("_id", uuids);
						arr4.add(0, tmpDLO);
					}
				}
			}
		}
		return toc;
	}

	// try delete

	@RequestMapping(value = "/dlodelete", method = RequestMethod.POST)
	public ArrayList deleteajaxcall(@RequestBody String str3) throws ParseException, IOException {
		this.str3 = str3;
		String[] parts = str3.split(",");
		ArrayList arr3 = new ArrayList<>(Arrays.asList(parts));
		return arr3;
	}

	public JSONObject delete() throws IOException, ParseException {
		JSONObject toc = creation();
		if (str3 != null) {
			ArrayList<String> myarr = deleteajaxcall(str3);

			JSONObject jso = (JSONObject) toc.get("toc");
			JSONArray arr1 = (JSONArray) jso.get("ge");
			for (int x = 0; x < arr1.size(); x++) {
				JSONObject chapter = (JSONObject) arr1.get(x);
				ArrayList arr2 = (ArrayList) chapter.get("ge");
				for (int y = 0; y < arr2.size(); y++) {
					JSONObject section = (JSONObject) arr2.get(y);
					ArrayList arr3 = (ArrayList) section.get("ge");
					for (int z = 0; z < arr3.size(); z++) {
						JSONObject topic = (JSONObject) arr3.get(z);
						ArrayList arr4 = (ArrayList) topic.get("ce");

						for (int u = arr4.size() - 1; u >= 0; u--) {
							JSONObject dlo = (JSONObject) arr4.get(u);
							for (int i = 0; i < myarr.size(); i++) { 
								if (dlo.get("_type").equals(myarr.get(i))) {
									arr4.remove(dlo);
								}
							}
						}
					}
				}
			}
		}
		return toc;
	}

	// check the synchronization of DLOs
	@ResponseBody
	public void dlosync() throws Exception {
		JSONObject object = creation();

		ArrayList<Integer> list = new ArrayList();
		ArrayList list2 = new ArrayList();
		ArrayList list3 = new ArrayList();
		ArrayList dlonamelist = new ArrayList();

		JSONObject jso = (JSONObject) object.get("toc");
		JSONArray arr1 = (JSONArray) jso.get("ge");
		for (int x = 0; x < arr1.size(); x++) {
			JSONObject chapter = (JSONObject) arr1.get(x);
			ArrayList arr2 = (ArrayList) chapter.get("ge");
			for (int y = 0; y < arr2.size(); y++) {
				JSONObject section = (JSONObject) arr2.get(y);
				ArrayList arr3 = (ArrayList) section.get("ge");
				for (int z = 0; z < arr3.size(); z++) {
					JSONObject topic = (JSONObject) arr3.get(z);
					ArrayList arr4 = (ArrayList) topic.get("ce");
					list.add(arr4.size()); // getting
					for (int v = 0; v < arr4.size(); v++) {
						JSONObject dlo = (JSONObject) arr4.get(v);
						String dloNames = dlo.get("_type").toString();
						dlonamelist.add(dloNames);
					}
				}
			}
		}
		// verifying the count
		boolean allTheSame = new HashSet<Integer>(list).size() == 1;
		if (allTheSame == false) {
			throw new Exception("DLOS count is different, Please check again!");
		}

		// verifying the synchronization
		int n = dlonamelist.size() / list.size();
		List<List<String>> output = new ArrayList<List<String>>();
		for (int v = 0; v < dlonamelist.size(); v += n) {
			String dloname = dlonamelist.get(v).toString();
			List<String> group = dlonamelist.subList(v, v + n);
			output.add(new ArrayList<String>(group));
		}
		for (int v1 = 0; v1 < output.size(); v1++) {
			ArrayList out2 = (ArrayList) output.get(v1);
			list3.add((out2.toString().hashCode()));
		}

		boolean syncSame = new HashSet<Integer>(list3).size() == 1;

		if (syncSame == false) {
			throw new Exception("Please check the synchronization of DLOs in each Topic");
		}
	}

	@RequestMapping(value = "/reverse", method = RequestMethod.GET)
	public String finalstep() throws IOException, ParseException, Exception {
		// dlosync();

		if(str2 != null) { JSONObject mytoc = dlouserposition(); }
		
		if(str2b != null) { JSONObject mytoc = dloposition1(); }
		
		if(str3 != null) { JSONObject mytoc = delete(); }
		
		if(str2 == null && str2b == null && str3 ==null) { JSONObject mytoc = creation(); }
		
		JSONObject json = (JSONObject) mytoc.get("toc");
		System.out.println(json.get("_display_name"));
		MongoClient mongo = new MongoClient("localhost", 27017);
		DB db = mongo.getDB("test");
		DBCollection collection = db.getCollection("lwjsons");
		BasicDBObject bd = new BasicDBObject("toc._display_name", json.get("_display_name")).append("toc._curriculum",
				json.get("_curriculum"));
		Cursor cursor = (Cursor) collection.find(bd);

//pushing updated or new json to database
		if (cursor.hasNext()) {
			String str = cursor.next().toString();
			Document doc = Document.parse(mytoc.toString());
			BasicDBObject originalQuery = new BasicDBObject(bd);
			BasicDBObject newDocument = new BasicDBObject();
			newDocument.append("$set", doc);
			collection.update(originalQuery, newDocument);
		} else {
			String strb = mytoc.toString();
			DBObject dbObject = (DBObject) JSON.parse(strb);
			collection.insert(dbObject);
		} 
		str2 = null;
		str2b = null;
		str3 = null;
		return "redirect:/gettoc?displaynam="+json.get("_display_name")+"&"+"curriculu="+json.get("_curriculum");
	}
}
//http://localhost:8080/tocadmin/second/gettoc?displaynam=science_6&curriculu=CBSE
//http://localhost:8080/tocadmin/gettoc?displaynam=science_6&curriculu=CBSE