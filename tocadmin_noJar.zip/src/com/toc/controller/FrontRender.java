package com.toc.controller;

import org.springframework.web.multipart.MultipartFile;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.servlet.http.HttpSession;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.ws.rs.FormParam;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.bson.Document;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import com.mongodb.BasicDBObject;
import com.mongodb.Cursor;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

@Controller
@ComponentScan
@SuppressWarnings("all")
public class FrontRender {
	JSONObject object, objecta, objectb, objectc, objectd;
	HashMap subjectMap = null;
	HashMap chapterMap = null;
	HashMap sectionMap = null;
	HashMap topicMap = null;
	HashMap topicDlosMap = null;
	HashMap subactivityMap = null;
	HashMap testmap = null; 
	HashMap dlosMap = null; 
	ArrayList arraylist = new ArrayList();
	ArrayList chapterIds = new ArrayList();
	ArrayList chapterTexts = new ArrayList();
	ArrayList chapterParents = new ArrayList();
	ArrayList sectionIds = new ArrayList();
	ArrayList sectionTexts = new ArrayList();
	ArrayList sectionParents = new ArrayList();
	ArrayList topicIds = new ArrayList();
	ArrayList topicTexts = new ArrayList();
	ArrayList topicParents = new ArrayList();
	ArrayList chapterDlosId = new ArrayList();
	ArrayList chapterDlosText = new ArrayList();
	ArrayList chapterDlosParent = new ArrayList();
	ArrayList sectionDlosId = new ArrayList();
	ArrayList sectionDlosText = new ArrayList();
	ArrayList sectionDlosParent = new ArrayList();
	ArrayList topicDlosId = new ArrayList();
	ArrayList topicDlosText = new ArrayList();
	ArrayList topicDlosParent = new ArrayList();
	ArrayList sceid = new ArrayList();
	ArrayList sceparent = new ArrayList();
	ArrayList scetext = new ArrayList();
	ArrayList scedata = new ArrayList();
	ArrayList chapterData = new ArrayList();
	ArrayList sectionData = new ArrayList();
	ArrayList topicData = new ArrayList();
	ArrayList topicce = new ArrayList();
	ArrayList topicDlosData = new ArrayList();
	ArrayList chapterDlosData = new ArrayList();   
	ArrayList subactivityList = new ArrayList(); 
	
	@RequestMapping(value = "/showpanel", method = RequestMethod.GET)
	public String first(Model model, Model modelb, Model modelc){ 
		ArrayList al = new ArrayList();
		ArrayList al2 = new ArrayList();
		ArrayList al3 = new ArrayList();
		ArrayList al4 = new ArrayList();
		MongoClient mongo = new MongoClient("localhost", 27017);
		DB db = mongo.getDB("test");
		DBCollection collection = db.getCollection("lwjsons");
        BasicDBObject query = new BasicDBObject();
        DBCursor cursor = collection.find(query);
   
		while(cursor.hasNext()){
		al.add(cursor.next());
		}
		
		for(int i=0; i<al.size(); i++) {
			HashMap h1 = (HashMap) al.get(i);
			h1.remove("_id");
			HashMap h2 = (HashMap) h1.get("toc");
			String mygrade = (String) h2.get("_display_name");
			String[] parts = mygrade.split("_");
			String displayPart = parts[0];						
			JSONObject obj = new JSONObject();
			obj.put("_display_name", displayPart);
			obj.put("_curriculum", h2.get("_curriculum"));
			obj.put("_grade", h2.get("_grade"));
			al2.add(obj);
			
			String primaryGrade = (String) h2.get("_grade");
			int priGrade = Integer.parseInt(primaryGrade);
			if(priGrade<6) {
				obj = new JSONObject();
				obj.put("_display_name", displayPart);
				obj.put("_curriculum", h2.get("_curriculum"));
				obj.put("_grade", h2.get("_grade"));
				al3.add(obj);				
			}else {
				obj = new JSONObject();
				obj.put("_display_name", displayPart);
				obj.put("_curriculum", h2.get("_curriculum"));
				obj.put("_grade", h2.get("_grade"));
				al4.add(obj);	
			}
		}
        model.addAttribute("collection", al2);
        modelb.addAttribute("pricollection", al3);
        modelc.addAttribute("seccollection", al4);        
        
		return "startup";
	}

	
	//Downloading ToC
	@RequestMapping(value = "/downloadtoc", method = RequestMethod.GET)
	public String downloadtoc(@RequestParam("display") String displayname, @RequestParam("cur") String curriculum) throws IOException, ParseException {
		MongoClient mongo = new MongoClient( "localhost", 27017);
		DB db = mongo.getDB("test");
		DBCollection collection = db.getCollection("lwjsons");
		BasicDBObject query = new BasicDBObject();
        DBCursor cursor = collection.find(query);   
        query.append("toc._display_name", displayname).append("toc._curriculum", curriculum);
		     
        if(cursor.hasNext()) {
			String str = cursor.next().toString();
			JSONParser parser = new JSONParser();
			object = (JSONObject) parser.parse(str);
			object.remove("_id");
			 final JFileChooser fc = new JFileChooser();
			    FileFilter filter = new FileNameExtensionFilter("json", new String[] {"json", "json"});
			    fc.setFileFilter(filter);
			    fc.addChoosableFileFilter(filter);
			     int userSelection = fc.showSaveDialog(null);
			     if(userSelection == JFileChooser.APPROVE_OPTION) {
			    	 File file = fc.getSelectedFile();
			    	 if(FilenameUtils.getExtension(file.getName()).equals("json")) {
			    	 }else{
			    		 file = new File(file.toString()+".json");
			    			 file = new File(file.getParentFile(), FilenameUtils.getBaseName(file.getName())+".json");
			    	 }
			    	 BufferedWriter writer = new BufferedWriter(new FileWriter(file)); 
			    	 writer.write(object.toString());	
					 writer.close();	
			     }		
		  }      
		return "flash";
	}
	
	//View ToC in DataBase
	    @ResponseBody
		@RequestMapping(value = "/viewtoc", method = RequestMethod.GET)
		public String viewtoc(@RequestParam("display") String displayname, @RequestParam("cur") String curriculum) throws IOException, ParseException {
			MongoClient mongo = new MongoClient( "localhost", 27017);
			DB db = mongo.getDB("test");
			DBCollection collection = db.getCollection("lwjsons");
			BasicDBObject query = new BasicDBObject();
	        DBCursor cursor = collection.find(query);   
	        query.append("toc._display_name", displayname).append("toc._curriculum", curriculum);
			     
	        if(cursor.hasNext()) {
				String str = cursor.next().toString();
				JSONParser parser = new JSONParser();
				object = (JSONObject) parser.parse(str);
				object.remove("_id");
			  }      
			return object.toString();
		}

	    
	// Service for Secondary grades
	@RequestMapping(value = "/service", method = RequestMethod.POST)
	public String login(@RequestParam("xl_file") MultipartFile file) throws IOException, ParseException{ 
		 File convFile = new File(file.getOriginalFilename());
		 convFile.createNewFile(); 
		 FileOutputStream fos = new FileOutputStream(convFile); 
		 fos.write(file.getBytes());
		 fos.close(); 
		 //first you are getting user uploaded excel file into your application.  Next you're feeding it as input to
		 //other service 
		 
		 String url = "http://localhost:3000/xl_to_json";	 
		 MultiValueMap<String, Object> body  = new LinkedMultiValueMap<>();
		 body.add("xl_file", new FileSystemResource(convFile));
		 RestTemplate restTemplate = new RestTemplate(); 
		 ResponseEntity<String> response = restTemplate.postForEntity(url, body, String.class);
		 
		 JSONParser parser = new JSONParser();
		 JSONObject jsonobject = (JSONObject) parser.parse(response.getBody());
		 JSONObject json = (JSONObject) jsonobject.get("toc"); 
		 MongoClient mongo = new MongoClient("localhost", 27017);
		 DB db = mongo.getDB("test");
		 DBCollection collection = db.getCollection("lwjsons");
		 BasicDBObject bd = new BasicDBObject("toc._display_name", json.get("_display_name")).append("toc._curriculum", json.get("_curriculum"));
		 Cursor cursor = (Cursor) collection.find(bd);
		 
		  if(cursor.hasNext()) { 
		 		String str =  cursor.next().toString();
		 		Document doc = Document.parse(jsonobject.toString());
		 		    BasicDBObject originalQuery = new BasicDBObject(bd);	
		 			BasicDBObject newDocument = new BasicDBObject();
		 			newDocument.append("$set", doc);
		 			collection.update(originalQuery, newDocument);
		  }else {
		 		String str2 =  jsonobject.toString();
		 		DBObject dbObject = (DBObject)JSON.parse(str2);			
		 		collection.insert(dbObject);
		 	}
		  return "flash";
	}
	

	///Service for Primary grades
	@RequestMapping(value = "/servicepri", method = RequestMethod.POST)
	public String login2(@RequestParam("xl_file") MultipartFile file) throws IOException, ParseException{ 
		 File convFile = new File(file.getOriginalFilename());
		 convFile.createNewFile(); 
		 FileOutputStream fos = new FileOutputStream(convFile); 
		 fos.write(file.getBytes());
		 fos.close(); 
		   
		 String url = "http://localhost:4000/xl_to_json";	 
		 MultiValueMap<String, Object> body  = new LinkedMultiValueMap<>();
		 body.add("xl_file", new FileSystemResource(convFile));
		 RestTemplate restTemplate = new RestTemplate(); 
		 ResponseEntity<String> response = restTemplate.postForEntity(url, body, String.class);
		 
		 JSONParser parser = new JSONParser();
		 JSONObject jsonobject = (JSONObject) parser.parse(response.getBody()); 
		 JSONObject json = (JSONObject) jsonobject.get("toc");          
		 MongoClient mongo = new MongoClient("localhost", 27017);
		 DB db = mongo.getDB("test");
		 DBCollection collection = db.getCollection("lwjsons");
		 BasicDBObject bd = new BasicDBObject("toc._display_name", json.get("_display_name")).append("toc._curriculum", json.get("_curriculum"));
		 Cursor cursor = (Cursor) collection.find(bd);

		  if(cursor.hasNext()) { 
		 		String str =  cursor.next().toString();
		 		Document doc = Document.parse(jsonobject.toString());
		 		    BasicDBObject originalQuery = new BasicDBObject(bd);	
		 			BasicDBObject newDocument = new BasicDBObject();
		 			newDocument.append("$set", doc);
		 			collection.update(originalQuery, newDocument);
		  }else {
		 		String str2 =  jsonobject.toString();
		 		DBObject dbObject = (DBObject)JSON.parse(str2);			
		 		collection.insert(dbObject);
		 	}
		  return "flash";
	}

	 //MODEL
	@RequestMapping(value = "/gettoc", method = {RequestMethod.GET,RequestMethod.POST})
	public String gettoc(@RequestParam("displaynam") String displayname, @RequestParam("curriculu") String curriculum, Model model) throws IOException, ParseException {
		MongoClient mongo = new MongoClient( "localhost", 27017);
		DB db = mongo.getDB("test");
		DBCollection collection = db.getCollection("lwjsons");
		BasicDBObject query = new BasicDBObject();
        DBCursor cursor = collection.find(query);
		query.append("toc._display_name", displayname).append("toc._curriculum", curriculum);
		while(cursor.hasNext()) {
			String file = cursor.next().toString();
			JSONParser parser = new JSONParser();
			object = (JSONObject) parser.parse(file);
			objecta = (JSONObject) parser.parse(file);
			objectb = (JSONObject) parser.parse(file);
			objectc = (JSONObject) parser.parse(file);
		}
		
///////////////subject level/////////////////////////////////////////////////////
		subjectMap = (HashMap) object.get("toc");
		subjectMap.put("id", "35");
		subjectMap.put("parent", "#");
		subjectMap.put("text", subjectMap.get("_display_name"));
		subjectMap.put("data", subjectMap.remove("ge"));
		ArrayList chapterList = (ArrayList) subjectMap.get("data");

////////////////////Chapter level///////////////////////////////////////////////
		for (int i = 0; i < chapterList.size(); i++) {
			chapterMap = (HashMap) chapterList.get(i);
            chapterMap.put("parent", subjectMap.get("id"));
			chapterMap.put("id", chapterMap.get("_id"));
			chapterMap.put("text", WordUtils.capitalizeFully(chapterMap.get("_display_name").toString()));
			chapterMap.put("data", chapterMap.remove("ge"));
			chapterIds.add(chapterMap.get("id"));
			chapterParents.add(chapterMap.get("parent"));
			chapterTexts.add(chapterMap.get("text"));

           // adding tests to Chapters
			ArrayList testlist = (ArrayList) chapterMap.get("ce");
			for (int u = 0; u < testlist.size(); u++) {
				testmap = (HashMap) testlist.get(u);
				testmap.put("parent", chapterMap.get("id"));
				testmap.put("text", testmap.get("_display_name"));
				chapterDlosText.add(testmap.get("text"));
                //generating unique ids 
				if (testmap.containsKey("text")) {
					String uuids = UUID.randomUUID().toString();
					testmap.put("id", uuids);
				}
				chapterDlosId.add(testmap.get("id"));
				testmap.put("parent", chapterMap.get("id"));
				chapterDlosParent.add(testmap.get("parent"));
			}

/////////////////////Section level////////////////////////////////////////////
			List sectionList = (ArrayList) chapterMap.get("data");

			for (int j = 0; j < sectionList.size(); j++) {
				sectionMap = (HashMap) sectionList.get(j);
				sectionMap.put("parent", chapterMap.get("id"));
				sectionMap.put("id", sectionMap.get("_id"));
				sectionMap.put("text", WordUtils.capitalizeFully(sectionMap.get("_display_name").toString()));
				sectionMap.put("data", sectionMap.remove("ge"));

				sectionIds.add(sectionMap.get("id"));
				sectionParents.add(sectionMap.get("parent"));
				sectionTexts.add(sectionMap.get("text"));

////////////////////////////////////////level topics////////////////////////////////////////////////
				ArrayList topicList = (ArrayList) sectionMap.get("data");
				for (int k = 0; k < topicList.size(); k++) {
					topicMap = (HashMap) topicList.get(k);
					topicMap.put("parent", sectionMap.get("id"));
					topicMap.put("id", topicMap.get("_id"));
					topicMap.put("text", WordUtils.capitalizeFully(topicMap.get("_display_name").toString()));
					
					String uuids3 = UUID.randomUUID().toString();
					topicMap.put("id", uuids3);

					topicIds.add(topicMap.get("id"));
					topicParents.add(topicMap.get("parent"));
					topicTexts.add(topicMap.get("text"));

                         //topic dlos
					ArrayList topicDloList = (ArrayList) topicMap.get("ce");
					for (int l = 0; l < topicDloList.size(); l++) {
						topicDlosMap = (HashMap) topicDloList.get(l);
						topicDlosMap.put("id", topicDlosMap.get("_id"));
						topicDlosMap.put("text", topicDlosMap.get("_display_name"));
						topicDlosMap.put("parent", topicMap.get("id"));
						
							String uuids2 = UUID.randomUUID().toString();
							topicDlosMap.put("id", uuids2);
							
						topicDlosId.add(topicDlosMap.get("id"));
						topicDlosParent.add(topicDlosMap.get("parent"));
						topicDlosText.add(topicDlosMap.get("text"));

                               //if contains sub-activities 
						if (topicDlosMap.containsKey("sce")) {
							 subactivityList = (ArrayList) topicDlosMap.get("sce");
							for (int m = 0; m < subactivityList.size(); m++) {
								subactivityMap = (HashMap) subactivityList.get(m);
								subactivityMap.put("text", subactivityMap.get("_display_name"));
								subactivityMap.put("id", subactivityMap.get("_id"));
								subactivityMap.put("parent", topicDlosMap.get("id"));
								if (subactivityMap.containsKey("id")) {
									String ids3 = UUID.randomUUID().toString();
									subactivityMap.put("id", ids3);
								}
								sceid.add(subactivityMap.get("id"));
								sceparent.add(subactivityMap.get("parent"));
								scetext.add(subactivityMap.get("text"));
								JSONObject subactivityData = new JSONObject();
								scedata.add(subactivityMap);
							}
						}
					}
				}
			}
		}
 
		/*
		 * collecting data from Chapters, Tests, Sections, Topics and DLOs
		 */

//subject level data
		objecta.put("data", objecta.remove("toc"));
		subjectMap = (HashMap) objecta.get("data");
		subjectMap.remove("ge");

//chapter level data
		subjectMap = (HashMap) object.get("toc");
		chapterList = (ArrayList) subjectMap.get("data");
		for (int i = 0; i < chapterList.size(); i++) {
			chapterMap = (HashMap) chapterList.get(i);

//tests are being added 
			ArrayList testlist = (ArrayList) chapterMap.get("ce");
			for (int i1 = 0; i1 < testlist.size(); i1++) {
				testmap = (HashMap) testlist.get(i1);
				chapterDlosData.add(testmap);
			}

			chapterMap.put("parent", subjectMap.get("id"));
			chapterMap.put("id", chapterMap.get("_id"));
			chapterMap.put("text", chapterMap.get("_display_name"));
			chapterMap.put("data", chapterMap.remove("ge"));

			JSONObject newTest = new JSONObject();
			newTest.put("data", chapterMap);
			JSONObject newTest2 = (JSONObject) newTest.get("data");
			newTest2.remove("data");
			newTest2.remove("parent");
			newTest2.remove("text");
			newTest2.remove("id");
			chapterData.add(newTest2);
		}
//section level data
		subjectMap = (HashMap) objectb.get("toc");
		subjectMap.put("id", "35");
		subjectMap.put("parent", "#");
		subjectMap.put("text", subjectMap.get("_display_name"));
		subjectMap.put("data", subjectMap.remove("ge"));
		chapterList = (ArrayList) subjectMap.get("data");

		for (int i = 0; i < chapterList.size(); i++) {
			chapterMap = (HashMap) chapterList.get(i);
			chapterMap.put("parent", subjectMap.get("id"));
			chapterMap.put("id", chapterMap.get("_id"));
			chapterMap.put("text", chapterMap.get("_display_name"));
			chapterMap.put("data", chapterMap.remove("ge"));

			ArrayList sectionList = (ArrayList) chapterMap.get("data");

			for (int j = 0; j < sectionList.size(); j++) {
				sectionMap = (HashMap) sectionList.get(j);
				sectionMap.put("parent", chapterMap.get("id"));
				sectionMap.put("id", sectionMap.get("_id"));
				sectionMap.put("text", sectionMap.get("_display_name"));
				sectionMap.put("data", sectionMap.remove("ge"));

				JSONObject json1 = new JSONObject();
				json1.put("data", sectionMap);
				JSONObject sectionDatas = (JSONObject) json1.get("data");
				sectionDatas.remove("data");
				sectionDatas.remove("parent");
				sectionDatas.remove("text");
				sectionDatas.remove("id");
				sectionData.add(sectionDatas);
			}
		}
//topic level data

		subjectMap = (HashMap) objectc.get("toc");
		subjectMap.put("id", "35");
		subjectMap.put("parent", "#");
		subjectMap.put("text", subjectMap.get("_display_name"));
		subjectMap.put("data", subjectMap.remove("ge"));
		chapterList = (ArrayList) subjectMap.get("data");

		for (int i = 0; i < chapterList.size(); i++) {
			chapterMap = (HashMap) chapterList.get(i);
			chapterMap.put("parent", subjectMap.get("id"));
			chapterMap.put("id", chapterMap.get("_id"));
			chapterMap.put("text", chapterMap.get("_display_name"));
			chapterMap.put("data", chapterMap.remove("ge"));

			ArrayList sectionList = (ArrayList) chapterMap.get("data");
			for (int j = 0; j < sectionList.size(); j++) {
				sectionMap = (HashMap) sectionList.get(j);
				sectionMap.put("parent", chapterMap.get("id"));
				sectionMap.put("id", sectionMap.get("_id"));
				sectionMap.put("text", sectionMap.get("_display_name"));
				sectionMap.put("data", sectionMap.remove("ge"));

				ArrayList topicList = (ArrayList) sectionMap.get("data");
				for (int k = 0; k < topicList.size(); k++) {
					topicMap = (HashMap) topicList.get(k);
					topicMap.put("parent", sectionMap.get("id"));
					topicMap.put("id", topicMap.get("_id"));
					topicMap.put("text", topicMap.get("_display_name"));

//adding data to topic CE's
					ArrayList topicDloList = (ArrayList) topicMap.get("ce");
					JSONObject topicdlo = new JSONObject();
					topicdlo.put("data", topicDloList);

//adding topic's data
					JSONObject json1 = new JSONObject();
					json1.put("data", topicMap);
					JSONObject topics = (JSONObject) json1.get("data");
					topics.remove("data");
					topics.remove("parent");
					topics.remove("text");
					topics.remove("id");
					topicData.add(topics);
					topicce.add(topicdlo); 
				}
			}
		} 

// -----------------------------------------------Framing my json to suit the front-end-----------------------------------------------------------//

		//Subject
		JSONObject object2 = new JSONObject();
		object2.put("id", subjectMap.get("id"));
		object2.put("text", subjectMap.get("text"));
		object2.put("parent", subjectMap.get("parent"));
		object2.put("data", subjectMap);
		object2.put("type", "subject");
		arraylist.add(object2);
 
		//Chapter
		for (int x = 0; x < chapterIds.size(); x++) {
			JSONObject object3 = new JSONObject();
			object3.put("id", chapterIds.get(x));
			object3.put("text", chapterTexts.get(x));
			object3.put("parent", chapterParents.get(x));
			object3.put("data", chapterData.get(x));
			object3.put("type", "chapter");
			arraylist.add(object3);
		}

		//Section
		for (int y = 0; y < sectionIds.size(); y++) {
			JSONObject object4 = new JSONObject();
			object4.put("id", sectionIds.get(y));
			object4.put("text", sectionTexts.get(y));
			object4.put("parent", sectionParents.get(y));
			object4.put("data", sectionData.get(y));
			object4.put("type", "section");
			arraylist.add(object4);
		}
		
		//Topic
		for (int z = 0; z < topicIds.size(); z++) {
			JSONObject object5 = new JSONObject();
			object5.put("id", topicIds.get(z));
			object5.put("text", topicTexts.get(z));
			object5.put("parent", topicParents.get(z));
			object5.put("data", topicData.get(z));
			object5.put("type", "topic");
			arraylist.add(object5);
		}

//adding the dlos to chapter, section, topic and subactivity
		
		//adding tests
		for (int a = 0; a < chapterDlosId.size(); a++) {
			JSONObject testobjects = new JSONObject();
			testobjects.put("id", chapterDlosId.get(a));
			testobjects.put("text", chapterDlosText.get(a));
			testobjects.put("parent", chapterDlosParent.get(a));
			testobjects.put("data", chapterDlosData.get(a));
			testobjects.put("type", "section");
			arraylist.add(testobjects);
		}

//data to topic dlos
		for (int d = 0; d < topicce.size(); d++) {
			JSONObject object6 = new JSONObject();
			object6.put("data", topicce.get(d));
			JSONObject secJson = (JSONObject) object6.get("data");
			ArrayList secData = (ArrayList) secJson.get("data");
			for (int e = 0; e < secData.size(); e++) {
				JSONObject dloJson = (JSONObject) secData.get(e);
				topicDlosData.add(dloJson);
			}
		} 
    
		//dlos
		for (int c = 0; c < topicDlosId.size(); c++) {
			JSONObject dloObjects = new JSONObject();
			dloObjects.put("id", topicDlosId.get(c));
			dloObjects.put("text", topicDlosText.get(c));
			dloObjects.put("parent", topicDlosParent.get(c));
			dloObjects.put("data", topicDlosData.get(c));
			dloObjects.put("type", "dlos");
			arraylist.add(dloObjects);
		} 
		  
		for(int f=0; f <sceid.size(); f++) {
			JSONObject subactivityObject = new JSONObject();
			subactivityObject.put("id", sceid.get(f));
			subactivityObject.put("text", scetext.get(f));
			subactivityObject.put("parent", sceparent.get(f));
			subactivityObject.put("data", scedata.get(f));
			arraylist.add(subactivityObject);	
		} 
		//System.out.println(arraylist);   
				 
        model.addAttribute("arrayasstring",arraylist.toString());
        arraylist.clear(); //clearing all the Arraylists used in Json creation
chapterIds.clear(); chapterTexts.clear(); chapterParents.clear(); chapterData.clear(); sectionIds.clear(); sectionTexts.clear(); sectionParents.clear(); sectionData.clear();
topicIds.clear(); topicTexts.clear(); topicParents.clear(); topicData.clear();
chapterDlosId.clear(); chapterDlosText.clear(); chapterDlosParent.clear(); chapterDlosData.clear(); sectionDlosId.clear(); sectionDlosText.clear(); sectionDlosParent.clear();
topicDlosId.clear(); topicDlosText.clear(); topicDlosParent.clear(); topicDlosData.clear(); sceid.clear(); scetext.clear(); sceparent.clear(); scedata.clear();
topicce.clear();

        return "index";
	} 
}