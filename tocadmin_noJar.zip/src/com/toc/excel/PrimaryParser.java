package com.toc.excel;
 
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;

@Controller
@ComponentScan
@SuppressWarnings("all")
public class PrimaryParser {
	JSONObject obj;
	
	@RequestMapping(value = "/primaryexcel", method = RequestMethod.GET)
	public String primary(@RequestParam("displaynam") String displayname, @RequestParam("curriculu") String curriculum) throws FileNotFoundException, IOException, ParseException {
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Sheet1");
	
		MongoClient mongo = new MongoClient( "localhost", 27017);
		DB db = mongo.getDB("test");
		DBCollection collection = db.getCollection("lwjsons");
		BasicDBObject query = new BasicDBObject();
        DBCursor cursor = collection.find(query);
		query.append("toc._display_name", displayname).append("toc._curriculum", curriculum);
		while(cursor.hasNext()) {
			String file = cursor.next().toString();
			JSONParser parser = new JSONParser();
			 obj = (JSONObject) parser.parse(file);
		}

		//Colors
		XSSFFont font = workbook.createFont();
		font.setBold(true);
		font.setColor(IndexedColors.WHITE.getIndex());
		CellStyle style = workbook.createCellStyle();
		style.setFont(font);
		style.setFillBackgroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		style.setFillPattern(FillPatternType.BIG_SPOTS);

		JSONObject mainToc = (JSONObject) obj;
		HashMap subMap = (HashMap) mainToc.get("toc");
		// Adding headers to Excel
		String display = (String) subMap.get("_display_name");
		String cur = (String) subMap.get("_curriculum");
		String grade = (String) subMap.get("_grade");

		Row row0 = sheet.createRow(0);
		Cell cell0 = row0.createCell(0);
		cell0.setCellValue("name");
		Cell cells0 = row0.createCell(1);
		cells0.setCellValue(display);

		Row row1 = sheet.createRow(1);
		Cell cell1 = row1.createCell(0);
		cell1.setCellValue("curriculam");
		Cell cells1 = row1.createCell(1);
		cells1.setCellValue(cur);

		Row row2 = sheet.createRow(2);
		Cell cell2 = row2.createCell(0);
		cell2.setCellValue("grade");
		Cell cells2 = row2.createCell(1);
		cells2.setCellValue(grade);

		Row row3 = sheet.createRow(3);
		Cell cell3 = row3.createCell(0);
		cell3.setCellValue("Chapter");
		Cell cells3 = row3.createCell(1);
		cells3.setCellValue("PQ,CQ");

		Row row4 = sheet.createRow(4);
		Cell cell4 = row4.createCell(0);
		cell4.setCellValue("Section");
		Cell cells4 = row4.createCell(1);
		cells4.setCellValue("");

		Row row5 = sheet.createRow(5);
		Cell cell5 = row5.createCell(0);
		cell5.setCellValue("Topic");
		Cell cells5 = row5.createCell(1);
		cells5.setCellValue("PQ,CQ");

		Row row6 = sheet.createRow(6);
		Cell cell6 = row6.createCell(0);
		cell6.setCellValue("Chapter No.");
		cell6.setCellStyle(style);

		Cell cellA = row6.createCell(1);
		cellA.setCellValue("Chapter");
		cellA.setCellStyle(style);

		Cell cellB = row6.createCell(2);
		cellB.setCellValue("Chapter Category Id");
		cellB.setCellStyle(style);

		Cell cellC = row6.createCell(3);
		cellC.setCellValue("Section");
		cellC.setCellStyle(style);

		Cell cellD = row6.createCell(4);
		cellD.setCellValue("Section Category Id");
		cellD.setCellStyle(style);

		Cell cellE = row6.createCell(5);
		cellE.setCellValue("FP Video ID");
		cellE.setCellStyle(style);

		Cell cellF = row6.createCell(6);
		cellF.setCellValue("Topic");
		cellF.setCellStyle(style);

		Cell cellG = row6.createCell(7);
		cellG.setCellValue("Topic Category Id");
		cellG.setCellStyle(style);

		Cell cellH = row6.createCell(8);
		cellH.setCellValue("VTT");
		cellH.setCellStyle(style);

		Cell cellI = row6.createCell(9);
		cellI.setCellValue("Video Links");
		cellI.setCellStyle(style);

		Cell cellJ = row6.createCell(10);
		cellJ.setCellValue("Activity1");
		cellJ.setCellStyle(style);

		Cell cellK = row6.createCell(11);
		cellK.setCellValue("Activity2");
		cellK.setCellStyle(style);

		Cell cellL = row6.createCell(12);
		cellL.setCellValue("Activity3");
		cellL.setCellStyle(style);

		Cell cellM = row6.createCell(13);
		cellM.setCellValue("Activity4");
		cellM.setCellStyle(style);

		Cell cellN = row6.createCell(14);
		cellN.setCellValue("Activity5");
		cellN.setCellStyle(style);

		Cell cellO = row6.createCell(15);
		cellO.setCellValue("Activity6");
		cellO.setCellStyle(style);

		Cell cellP = row6.createCell(16);
		cellP.setCellValue("Objective");
		cellP.setCellStyle(style);
 
//----------------Algorithm to populate Excel from JSON----------------------------
		ArrayList chapList = (ArrayList) subMap.get("ge");
		int uniqueRow = 7;
		for (int i = 0; i < chapList.size(); i++) {
			// starts Chapters
			Row chapterRow = sheet.createRow(uniqueRow++);
			HashMap chapMap = (HashMap) chapList.get(i);
			Cell chapterNo = chapterRow.createCell(0);
			chapterNo.setCellValue(i + 1);

			Cell chapterCell = chapterRow.createCell(1);
			chapterCell.setCellValue(WordUtils.capitalizeFully(chapMap.get("_display_name").toString()));

			ArrayList chapAl = (ArrayList) chapMap.get("_qat_category_id");
			Cell qatChapCell = chapterRow.createCell(2);
			qatChapCell.setCellValue(chapAl.get(0).toString());

			// starts Sections
			ArrayList secList = (ArrayList) chapMap.get("ge");
			for (int j = 0; j < secList.size(); j++) {
				Row sectionRow = sheet.createRow(uniqueRow++);
				HashMap secMap = (HashMap) secList.get(j);
				Cell sectionCell = sectionRow.createCell(3);
				sectionCell.setCellValue(WordUtils.capitalizeFully(secMap.get("_display_name").toString()));
				
				ArrayList secAl = (ArrayList) secMap.get("_qat_category_id");
				Cell qatSecCell = sectionRow.createCell(4);
				qatSecCell.setCellValue(secAl.get(0).toString());

				// starts Topics
				ArrayList topList = (ArrayList) secMap.get("ge");
				for (int k = 0; k < topList.size(); k++) {
					Row topicRow = sheet.createRow(uniqueRow++);
					HashMap topicMap = (HashMap) topList.get(k);
					Cell topicCell = topicRow.createCell(6);
					topicCell.setCellValue(WordUtils.capitalizeFully(topicMap.get("_display_name").toString()));

					Cell topicIdCell = topicRow.createCell(5);
					topicIdCell.setCellValue(topicMap.get("_id").toString());

					ArrayList topicAl = (ArrayList) topicMap.get("_qat_category_id");
					Cell qatTopicCell = topicRow.createCell(7);
					qatTopicCell.setCellValue(topicAl.get(0).toString());
					
					Cell objCell = topicRow.createCell(16);
					objCell.setCellValue(topicMap.get("_description").toString());

					// starts Dlos
					ArrayList dloList = (ArrayList) topicMap.get("ce");
					for (int l = 0; l < dloList.size(); l++) {
						HashMap dloMap = (HashMap) dloList.get(l);
		        		if(dloMap.size()==11 | dloMap.size()==10) {
						String string = dloMap.get("_url").toString();
						String[] parts = string.split("/");
						Cell dloCellOne = topicRow.createCell(9);
						dloCellOne.setCellValue(parts[2]);
					}
				}
				
					// start subActivities. There are total 6 columns need to be filled
					for (int m = 0; m < dloList.size(); m++) {
						HashMap dloMap = (HashMap) dloList.get(m);
						
						ArrayList a = new ArrayList();
						// activity 1
						if (dloMap.containsValue("Activity 1")) {
							if (dloMap.get("sce") != null) {
								ArrayList sceList = (ArrayList) dloMap.get("sce");
								for (int n = 0; n < sceList.size(); n++) {
									HashMap sceMap = (HashMap) sceList.get(n);						
									String string = sceMap.get("_url").toString();
									
									//pattern and throw exception
									Pattern pattern = Pattern.compile("/(.*?)(?=/|$)");
									Matcher matcher = pattern.matcher(string);
									while(matcher.find()) {
										matcher.group(1);
									}									
									try{
										String[] parts = string.split("/");
										a.add(parts[1]);
									}catch(Exception e){
									System.out.println("url is not correct in subActivity 1");
									}
									
								}
								Cell cellAc1 = topicRow.createCell(10);
								cellAc1.setCellValue(a.toString().substring(1, a.toString().length() - 1));
							} else {
								Cell cellAc1 = topicRow.createCell(10);
								cellAc1.setCellValue("Activity1");
							}
						}

						// activity 2
						if (dloMap.containsValue("Activity 2")) {
							if (dloMap.get("sce") != null) {
								ArrayList sceList = (ArrayList) dloMap.get("sce");
								for (int n = 0; n < sceList.size(); n++) {
									HashMap sceMap = (HashMap) sceList.get(n);
									String string = sceMap.get("_url").toString();
									String[] parts = string.split("/");
									a.add(parts[1]);
								}
								Cell cellAc1 = topicRow.createCell(11);
								cellAc1.setCellValue(a.toString().substring(1, a.toString().length() - 1));
							} else {
								Cell cellAc1 = topicRow.createCell(11);
								cellAc1.setCellValue("Activity2");
							}
						}

						// activity 3
						if (dloMap.containsValue("Activity 3")) {
							if (dloMap.get("sce") != null) {
								ArrayList sceList = (ArrayList) dloMap.get("sce");
								for (int n = 0; n < sceList.size(); n++) {
									HashMap sceMap = (HashMap) sceList.get(n);
									String string = sceMap.get("_url").toString();
									String[] parts = string.split("/");
									a.add(parts[1]);
								}
								Cell cellAc1 = topicRow.createCell(12);
								cellAc1.setCellValue(a.toString().substring(1, a.toString().length() - 1));
							} else {
								Cell cellAc1 = topicRow.createCell(12);
								cellAc1.setCellValue("Activity3");
							}
						}

						// activity 4
						if (dloMap.containsValue("Activity 4")) {
							if (dloMap.get("sce") != null) {
								ArrayList sceList = (ArrayList) dloMap.get("sce");
								for (int n = 0; n < sceList.size(); n++) {
									HashMap sceMap = (HashMap) sceList.get(n);
									String string = sceMap.get("_url").toString();
									String[] parts = string.split("/");
									a.add(parts[1]);
								}
								Cell cellAc1 = topicRow.createCell(13);
								cellAc1.setCellValue(a.toString().substring(1, a.toString().length() - 1));
							} else {
								Cell cellAc1 = topicRow.createCell(13);
								cellAc1.setCellValue("Activity4");
							}
						}

						// activity 5
						if (dloMap.containsValue("Activity 5")) {
							if (dloMap.get("sce") != null) {
								ArrayList sceList = (ArrayList) dloMap.get("sce");
								for (int n = 0; n < sceList.size(); n++) {
									HashMap sceMap = (HashMap) sceList.get(n);
									String string = sceMap.get("_url").toString();
									String[] parts = string.split("/");
									a.add(parts[1]);
								}
								Cell cellAc1 = topicRow.createCell(14);
								cellAc1.setCellValue(a.toString().substring(1, a.toString().length() - 1));
							} else {
								Cell cellAc1 = topicRow.createCell(14);
								cellAc1.setCellValue("Activity5");
							}
						}

						// activity 6
						if (dloMap.containsValue("Activity 6")) {
							if (dloMap.get("sce") != null) {
								ArrayList sceList = (ArrayList) dloMap.get("sce");
								for (int n = 0; n < sceList.size(); n++) {
									HashMap sceMap = (HashMap) sceList.get(n);
									String string = sceMap.get("_url").toString();
									String[] parts = string.split("/");
									a.add(parts[1]);
								}
								Cell cellAc1 = topicRow.createCell(15);
								cellAc1.setCellValue(a.toString().substring(1, a.toString().length() - 1));
							} else {
								Cell cellAc1 = topicRow.createCell(15);
								cellAc1.setCellValue("Activity6");
							}
						}
					}
				}
			}
		}
		 
		for (int a = 0; a < 17; a++) {
			// autoExpand all columns
			sheet.autoSizeColumn(a);
		}

    final JFileChooser fc = new JFileChooser();
    FileFilter filter = new FileNameExtensionFilter("xlsx", new String[] {"xlsx", "excel"});
    fc.setFileFilter(filter);
    fc.addChoosableFileFilter(filter);
     int userSelection = fc.showSaveDialog(null);
     if(userSelection == JFileChooser.APPROVE_OPTION) {
    	 File file = fc.getSelectedFile();
    	 if(FilenameUtils.getExtension(file.getName()).equals("xlsx")) {
    	 }else{
    		 file = new File(file.toString()+".xlsx");
    			 file = new File(file.getParentFile(), FilenameUtils.getBaseName(file.getName())+".xlsx");
    		 }
         FileOutputStream fos = new FileOutputStream(file);
  			workbook.write(fos);
  			fos.close(); 
  			workbook.close();
     }
		return "flash";
	}
}