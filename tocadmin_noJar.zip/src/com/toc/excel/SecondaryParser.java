package com.toc.excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;

@Controller
@ComponentScan
@SuppressWarnings("all")
public class SecondaryParser {
	JSONObject obj;
	
	@RequestMapping(value = "/secondaryexcel", method = RequestMethod.GET)
	public String secondary(@RequestParam("displaynam") String displayname, @RequestParam("curriculu") String curriculum) throws FileNotFoundException, IOException, ParseException {
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Sheet1");
	
		MongoClient mongo = new MongoClient( "localhost", 27017);
		DB db = mongo.getDB("test");
		DBCollection collection = db.getCollection("lwjsons");
		BasicDBObject query = new BasicDBObject();
        DBCursor cursor = collection.find(query);
		query.append("toc._display_name", displayname).append("toc._curriculum", curriculum);
		while(cursor.hasNext()) {
			String file = cursor.next().toString();
			JSONParser parser = new JSONParser();
			 obj = (JSONObject) parser.parse(file);
		}

    //colors
    XSSFFont font = workbook.createFont();
    font.setBold(true);
    font.setColor(IndexedColors.WHITE.getIndex());
    CellStyle style = workbook.createCellStyle();
    style.setFont(font);
    style.setFillBackgroundColor(IndexedColors.GREY_25_PERCENT.getIndex());  
    style.setFillPattern(FillPatternType.BIG_SPOTS);
   
    JSONObject mainToc = (JSONObject) obj;
	HashMap subMap = (HashMap) mainToc.get("toc");
    //Adding headers to Excel
    String display = (String) subMap.get("_display_name");
	String cur = (String) subMap.get("_curriculum");
	String grade = (String) subMap.get("_grade");
	
	Row row0 = sheet.createRow(0);
	Cell cell0 = row0.createCell(0);
	cell0.setCellValue("name");
	Cell cells0 = row0.createCell(1);
	cells0.setCellValue(display);   	

	Row row1 = sheet.createRow(1);
	Cell cell1 = row1.createCell(0);
	cell1.setCellValue("curriculam");
	Cell cells1 = row1.createCell(1);
	cells1.setCellValue(cur);
	
	Row row2 = sheet.createRow(2);
	Cell cell2 = row2.createCell(0);
	cell2.setCellValue("grade");
	Cell cells2 = row2.createCell(1);
	cells2.setCellValue(grade);
	
	Row row3 = sheet.createRow(3);
	Cell cell3 = row3.createCell(0);
	cell3.setCellValue("Chapter");
	Cell cells3 = row3.createCell(1);
	cells3.setCellValue("PQ,CQ");
	
	Row row4 = sheet.createRow(4);
	Cell cell4 = row4.createCell(0);
	cell4.setCellValue("Section");
	Cell cells4 = row4.createCell(1);
	cells4.setCellValue("");
	
	Row row5 = sheet.createRow(5);
	Cell cell5 = row5.createCell(0);
	cell5.setCellValue("Topic");
	Cell cells5 = row5.createCell(1);
	cells5.setCellValue("LQ,CQ");
	   	
	Row row6 = sheet.createRow(6);	
	Cell cell6 = row6.createCell(0);
	cell6.setCellValue("Chapter No.");
	cell6.setCellStyle(style);
	
	Cell cellA = row6.createCell(1);
	cellA.setCellValue("Chapter");
	cellA.setCellStyle(style);
	
	Cell cellB = row6.createCell(2);
	cellB.setCellValue("Chapter Category Id");
	cellB.setCellStyle(style);
	
	Cell cellC = row6.createCell(3);
	cellC.setCellValue("Section");
	cellC.setCellStyle(style);
	
	Cell cellD = row6.createCell(4);
	cellD.setCellValue("Section Category Id");
	cellD.setCellStyle(style);
	
	Cell cellE = row6.createCell(5);
	cellE.setCellValue("Topic ID");
	cellE.setCellStyle(style);
	
	Cell cellF = row6.createCell(6);
	cellF.setCellValue("Topic");
	cellF.setCellStyle(style);
	
	Cell cellG = row6.createCell(7);
	cellG.setCellValue("QAT Topic Category Id");
	cellG.setCellStyle(style);
	
	Cell cellH = row6.createCell(8);
	cellH.setCellValue("VTT Topic Category Id");
	cellH.setCellStyle(style);
	
	Cell cellI = row6.createCell(9);
	cellI.setCellValue("Video links");
	cellI.setCellStyle(style);

	
//----------------Algorithm to populate Excel from JSON----------------------------
	ArrayList chapList  = (ArrayList) subMap.get("ge"); 	
	int uniqueRow = 7;
	for(int i=0;i<chapList.size();i++) {
	//starts Chapters
		Row chapterRow = sheet.createRow(uniqueRow++);
		HashMap chapMap = (HashMap) chapList.get(i);
		Cell chapterNo = chapterRow.createCell(0);
		chapterNo.setCellValue(i+1);
		
		Cell chapterCell = chapterRow.createCell(1);
		chapterCell.setCellValue(WordUtils.capitalizeFully(chapMap.get("_display_name").toString()));		
		ArrayList chapAl =(ArrayList) chapMap.get("_qat_category_id");
		Cell qatChapCell = chapterRow.createCell(2);
		qatChapCell.setCellValue(chapAl.get(0).toString());
	
		
	//starts Sections		    		
		ArrayList secList = (ArrayList) chapMap.get("ge");
		for(int j=0;j<secList.size();j++) {
			Row sectionRow = sheet.createRow(uniqueRow++);
			HashMap secMap = (HashMap) secList.get(j);
			Cell sectionCell = sectionRow.createCell(3);
			sectionCell.setCellValue(WordUtils.capitalizeFully(secMap.get("_display_name").toString()));
			
			ArrayList secAl =(ArrayList) secMap.get("_qat_category_id");
    		Cell qatSecCell = sectionRow.createCell(4);
    		qatSecCell.setCellValue(secAl.get(0).toString());   
    		
    		
	//starts Topics
    		ArrayList topList = (ArrayList) secMap.get("ge");
    		for(int k=0;k<topList.size();k++) {
    			Row topicRow = sheet.createRow(uniqueRow++);
    			HashMap topicMap = (HashMap) topList.get(k);
    			Cell topicCell = topicRow.createCell(6);
				topicCell.setCellValue(WordUtils.capitalizeFully(topicMap.get("_display_name").toString()));
				  			
    			Cell topicIdCell = topicRow.createCell(5);
    			topicIdCell.setCellValue(topicMap.get("_id").toString());
    			
    			ArrayList topicAl =(ArrayList) topicMap.get("_qat_category_id");
        		Cell qatTopicCell = topicRow.createCell(7);
        		qatTopicCell.setCellValue(topicAl.get(0).toString());
        		
        		
     //starts Dlos
        		ArrayList dloList = (ArrayList) topicMap.get("ce");
        		for(int l=0;l<dloList.size();l++) {
        		HashMap dloMap = (HashMap) dloList.get(l);
        		if(dloMap.size()==10 | dloMap.size()==11) {
        		String string = dloMap.get("_url").toString();
        		String[] parts = string.split("/");
        		Cell dloCell = topicRow.createCell(9);
        		dloCell.setCellValue(parts[2]);
      		}  		
			}		
		} 		
	}
	}
	
	for(int a=0;a<10;a++) {
		//autoExpand all columns
		sheet.autoSizeColumn(a);
	}
	  final JFileChooser fc = new JFileChooser();
	    FileFilter filter = new FileNameExtensionFilter("xlsx", new String[] {"xlsx", "excel"});
	    fc.setFileFilter(filter);
	    fc.addChoosableFileFilter(filter);
	     int userSelection = fc.showSaveDialog(null);
	     if(userSelection == JFileChooser.APPROVE_OPTION) {
	    	 File file = fc.getSelectedFile();
	    	 if(FilenameUtils.getExtension(file.getName()).equals("xlsx")) {
	    		// filename is OK as-is
	    	 }else{
	    		 file = new File(file.toString()+".xlsx");
	    		// append .xml if "foo.jpg.xlsx" is OK
	    	    //file = new File(file.toString()+".xlsx");
	    	    //ALTERNATIVELY: remove the extension (if any) and replace it with ".xlsx"
	    			 file = new File(file.getParentFile(), FilenameUtils.getBaseName(file.getName())+".xlsx");
	    		 }
	         FileOutputStream fos = new FileOutputStream(file);
	  			workbook.write(fos);
	  			fos.close(); 
	  			workbook.close();
	     }
			return "flash";

		}
}