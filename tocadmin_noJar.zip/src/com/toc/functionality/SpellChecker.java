package com.toc.functionality;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.TreeSet;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
      
@Controller
@ComponentScan
@SuppressWarnings("all")
public class SpellChecker {
	String str;
	JSONObject object;

	@RequestMapping(value = "/checker", method = RequestMethod.GET)
	public String spellingchecker(@RequestParam("display") String displayname, @RequestParam("cur") String curriculum, Model model) throws IOException, ParseException {
		MongoClient mongo = new MongoClient( "localhost", 27017);
		DB db = mongo.getDB("test");
		DBCollection collection = db.getCollection("lwjsons");
		BasicDBObject query = new BasicDBObject();
        DBCursor cursor = collection.find(query);
		query.append("toc._display_name", displayname).append("toc._curriculum", curriculum);
		while(cursor.hasNext()) {
			String file = cursor.next().toString();
			JSONParser parser = new JSONParser();
			object = (JSONObject) parser.parse(file);
		}
		
		ArrayList chaps = new ArrayList();
		ArrayList chapmethod = new ArrayList();
		ArrayList chapadd = new ArrayList();
		ArrayList secs = new ArrayList();
		ArrayList secmethod = new ArrayList();
		ArrayList secadd = new ArrayList();
		ArrayList topics = new ArrayList();
		ArrayList topicmethod = new ArrayList();
		ArrayList topicadd = new ArrayList();
		
		JSONObject j1 = (JSONObject) object.get("toc");
		JSONArray arr1 = (JSONArray) j1.get("ge");	
		for(int i=0; i<arr1.size();i++) {
			JSONObject chapter = (JSONObject) arr1.get(i);
			String chapnames = chapter.get("_display_name").toString();
			chaps.add(chapnames);
			ArrayList arr2 = (ArrayList) chapter.get("ge");
			for(int j=0; j<arr2.size();j++) {
			JSONObject section = (JSONObject) arr2.get(j);
			String secnames = section.get("_display_name").toString();
			secs.add(secnames);
			ArrayList arr3 = (ArrayList) section.get("ge");
			for(int k=0; k<arr3.size();k++) {
			JSONObject topic = (JSONObject) arr3.get(k);
			String topicnames = topic.get("_display_name").toString();
			topics.add(topicnames);
		}
		}
		}
		
	//chapter Correction
		for(int i=0; i<chaps.size();i++) {
         chapmethod=checkme(chaps.get(i).toString(), "Chapter", i);
         StringBuffer sb = new StringBuffer();
		    //sb.append("[");
		    for(int j=0; j<chapmethod.size(); j++){
		        //sb.append("\"").append(chapmethod.get(j)).append("\"");
		    	 sb.append(chapmethod.get(j));
		    	if(j+1 < chapmethod.size()){
		    		sb.append(",");
		        }	    	
		    }
		    //sb.append("]");
	         String str = sb.toString().replaceAll(" xxx,", " ");
		    
         if(chapmethod.size()!=0) {
        	 chapadd.add(str);
         } 	   
		   model.addAttribute("myChapters", chapadd);
		}
		
		
		//sectionCorrection
		for(int i=0; i<secs.size();i++) {
	         secmethod=checkme(secs.get(i).toString(), "Section", i);
	         StringBuffer sb = new StringBuffer();
			    for(int j=0; j<secmethod.size(); j++){
			        sb.append(secmethod.get(j));
			        if(j+1 < secmethod.size()){
			            sb.append(",");
			        }
			    }
			    String str = sb.toString().replaceAll(" xxx,", "");
	         if(secmethod.size()!=0) {
	        	 secadd.add(str);
	         }
			   model.addAttribute("mySections", secadd);
			}
		
		//topicCorrection
		for(int i=0; i<topics.size();i++) {
	         topicmethod=checkme(topics.get(i).toString(), "Topic", i);
	         StringBuffer sb = new StringBuffer();
			    for(int j=0; j<topicmethod.size(); j++){
			        sb.append(topicmethod.get(j));
			        if(j+1 < topicmethod.size()){
			            sb.append(",");
			        }
			    }
			    String str = sb.toString().replaceAll(" xxx,", "");
	         if(topicmethod.size()!=0) {
	        	 topicadd.add(str);
	         }
			   model.addAttribute("myTopics", topicadd);
			}
		
		return "test";	
	}

	 //method
	 static ArrayList checkme(String string, String s, int i) throws FileNotFoundException {    
	        HashSet<String> dict = new HashSet<String>();
	        Scanner words = new Scanner(new File("/usr/share/dict/words"));
	        ArrayList aa = new ArrayList();
	        
	            while (words.hasNext()) {
	                String word = words.next();
	                dict.add(word.toLowerCase());
	            }
         
	            Scanner userFile = new Scanner(string);
	            userFile.useDelimiter("[^a-zA-Z]+");
	            
	            HashSet<String> badWords = new HashSet<String>();
	            while (userFile.hasNext()) {
	                String userWord = userFile.next();
	                userWord = userWord.toLowerCase();
	                if (!dict.contains(userWord))  {   
	                	badWords.add(userWord);
	                     TreeSet<String> goodWords = new TreeSet<String>();
	                     SpellChecker sc = new SpellChecker();         
	                     goodWords = sc.corrections(userWord, dict);
	                     aa.add(s+" "+(i+1)+" ("+string+") "+"- - - -"+userWord + ": "+"xxx");
	                     if (goodWords.isEmpty()) {
	                    	 aa.add("(no suggestions)");
	                     } else {
	                         for (String goodWord: goodWords) {
	                        	 aa.add(" "+goodWord);
	                         }
	                     }                  
	                }     
	            }
				return aa;
	       }
	 
 
     public TreeSet corrections(String badWord, HashSet dictionary) {
    	  TreeSet<String> possibleWords =  new TreeSet<String>();
          String subStr1, subStr2, possibility;
          
          for (int i = 0; i < badWord.length(); i++) {
        	  
              // Delete any one of the letters from the misspelled word like "unhaaalthy"
              subStr1 = badWord.substring(0, i);
              subStr2 = badWord.substring(i + 1);
              possibility = subStr1 + subStr2;
              if (dictionary.contains(possibility)) {
                  possibleWords.add(possibility);
              }
              
              // Change any letter in the misspelled word into other letter like "hhalthy"
              for (char ch = 'a'; ch <= 'z'; ch++) {
                  possibility = subStr1 + ch + subStr2;
                  if (dictionary.contains(possibility)){
                      possibleWords.add(possibility);
                  }
              }

              // Split the word and  Insert any letter at any point in the misspelled word like "halthy"
              subStr1 = badWord.substring(0, i);
              subStr2 = badWord.substring(i);
               for (char ch = 'a'; ch <= 'z'; ch++) {
                  possibility = subStr1 + ch + subStr2;
                  if (dictionary.contains(possibility)) {
                      possibleWords.add(possibility);
                  }
              }
              
          	//insert a space and try in misspelled word like "upto"
         	  char ch = ' ';
              possibility = subStr1 + ch + subStr2;
              if (dictionary.contains(subStr1) && dictionary.contains(subStr2)) {
              possibleWords.add(possibility);
          }             
          }
          
          // Swap any two neighboring characters in the misspelled word like "haelthy"
          for (int i = 1; i < badWord.length(); i++) {
              subStr1 = badWord.substring(0, i - 1);
              char ch1 = badWord.charAt(i - 1);
              char ch2 = badWord.charAt(i);
              subStr2 = badWord.substring(i + 1);
              possibility = subStr1 + ch2 + ch1 + subStr2;
              if (dictionary.contains(possibility)) {
                  possibleWords.add(possibility);
              }
          }
          return possibleWords; 
    }
}